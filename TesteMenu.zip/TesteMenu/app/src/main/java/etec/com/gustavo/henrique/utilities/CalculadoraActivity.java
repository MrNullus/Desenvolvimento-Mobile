package etec.com.gustavo.henrique.utilities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import etec.com.gustavo.henrique.appUtils.R;

public class CalculadoraActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(etec.com.gustavo.henrique.appUtils.R.layout.activity_calculadora);
    }
}